package librarymanagement;
import java.sql.*;

public class BookManager {

    public void addBook(Book book) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "INSERT INTO books(title,author,status) VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, "Available");

            ps.executeUpdate();

            System.out.println("Book added successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewBooks() {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM books";

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("author") + " | " +
                        rs.getString("status")
                );

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteBook(int id) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "DELETE FROM books WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Book deleted successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void issueBook(int id) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "UPDATE books SET status='Issued' WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Book issued successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void returnBook(int id) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "UPDATE books SET status='Available' WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Book returned successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
