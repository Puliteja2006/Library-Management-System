package librarymanagement;
import java.util.Scanner;

public class LibraryApp {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        BookManager manager = new BookManager();

        while (true) {

            System.out.println("\n----- Library Management System -----");
            System.out.println("1 Add Book");
            System.out.println("2 View Books");
            System.out.println("3 Issue Book");
            System.out.println("4 Return Book");
            System.out.println("5 Delete Book");
            System.out.println("6 Exit");

            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:

                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();

                    System.out.print("Enter author name: ");
                    String author = scanner.nextLine();

                    Book book = new Book(title, author);

                    manager.addBook(book);

                    break;

                case 2:
                    manager.viewBooks();
                    break;

                case 3:

                    System.out.print("Enter book ID to issue: ");
                    int issueId = scanner.nextInt();

                    manager.issueBook(issueId);

                    break;

                case 4:

                    System.out.print("Enter book ID to return: ");
                    int returnId = scanner.nextInt();

                    manager.returnBook(returnId);

                    break;

                case 5:

                    System.out.print("Enter book ID to delete: ");
                    int deleteId = scanner.nextInt();

                    manager.deleteBook(deleteId);

                    break;

                case 6:
                    System.exit(0);

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
